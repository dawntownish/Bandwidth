// Tiny local backend. Run it with:  npm start   (needs Node 20.6 or newer)
// The API key lives ONLY in .env, which is git-ignored. Never paste it into code.

const http = require("http");
const { appearsInSource, splitSentences } = require("./verify");

const PORT = process.env.PORT || 3000;

// Two providers. Fill in whichever you have; if only one is set, it handles everything.
const PROVIDERS = {
  // Muse Spark through the Meta Model API
  spark: {
    label: "Muse Spark",
    url: process.env.META_API_URL || "",
    key: process.env.META_API_KEY || "", // <-- stays in .env, never in code
    model: process.env.META_MODEL || "",
  },
  // Muse Spark Open (open weights) served by Baseten. This is the one that counts for the open-weights bonus.
  open: {
    label: "Muse Spark Open",
    url: process.env.OPEN_API_URL || "https://inference.baseten.co/v1/chat/completions",
    key: process.env.OPEN_API_KEY || "",
    model: process.env.OPEN_MODEL || "meta-models/muse-spark-open-1026",
  },
};

// Which model does which job. Change these to re-route a feature.
const TASK_PROVIDER = { summary: "open", mindmap: "spark", complexity: "spark", chemistry: "spark" };

function configured(p) { return !!(p.key && p.url && p.model); }

// ---------- the ONE place that talks to a model ----------
async function callModel(prompt, task) {
  const first = TASK_PROVIDER[task] || "spark";
  const second = first === "spark" ? "open" : "spark";
  const name = configured(PROVIDERS[first]) ? first : configured(PROVIDERS[second]) ? second : null;
  if (!name) return { ok: false, error: "not_configured" };
  const p = PROVIDERS[name];
  console.log(`[${task}] using ${p.label}`);

  try {
    // Chat Completions format (both Meta Model API and Baseten document this endpoint).
    const res = await fetch(p.url, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${p.key}` },
      body: JSON.stringify({
        model: p.model,
        messages: [{ role: "user", content: prompt }],
      }),
    });
    if (!res.ok) {
      // Shows WHY it failed in this terminal (never prints your key).
      const detail = (await res.text()).slice(0, 400);
      console.error(`${p.label} error ${res.status}: ${detail}`);
      return { ok: false, error: "model_error" };
    }
    const json = await res.json();
    const text = json && json.choices && json.choices[0] && json.choices[0].message
      ? json.choices[0].message.content
      : null;
    if (typeof text !== "string") return { ok: false, error: "model_error" };
    return { ok: true, text, via: p.label };
  } catch (err) {
    console.error(`Could not reach ${p.label}:`, err.message);
    return { ok: false, error: "model_error" };
  }
}

function parseJson(text) {
  try {
    return JSON.parse(text.replace(/```json|```/g, "").trim());
  } catch (err) {
    return null;
  }
}

// ---------- features ----------
const TIER_FRACTION = { light: 0.25, medium: 0.5, full: 0.75 };

async function summary({ text, tier }) {
  if (typeof text !== "string" || !text.trim()) return { ok: false, error: "bad_request" };
  const sentences = splitSentences(text).map((s) => s.trim()).filter(Boolean);
  if (sentences.length < 3) return { ok: false, error: "too_short" };

  const fraction = TIER_FRACTION[tier] || TIER_FRACTION.medium;
  const n = Math.max(1, Math.round(sentences.length * fraction));

  const prompt =
    `You are selecting sentences, not writing. From the TEXT below, choose the ${n} most ` +
    `important sentences and copy each one EXACTLY, character for character. Do not ` +
    `paraphrase, merge, shorten or add anything. Return only JSON like ` +
    `{"sentences": ["...", "..."]}. If you cannot choose reliably, return {"sentences": []}.\n\nTEXT:\n${text}`;

  const out = await callModel(prompt, "summary");
  if (!out.ok) return out;

  const parsed = parseJson(out.text);
  const picked = parsed && Array.isArray(parsed.sentences) ? parsed.sentences : [];

  // Keep only sentences that really exist in the original, in original order.
  const verified = sentences.filter((orig) =>
    picked.some((p) => typeof p === "string" && appearsInSource(p, orig) && appearsInSource(orig, p))
  );

  if (!verified.length) return { ok: false, error: "unverified" };
  return { ok: true, data: { lines: verified }, via: out.via };
}

async function mindmap() { return { ok: false, error: "not_implemented" }; } // TODO
async function complexity() { return { ok: false, error: "not_implemented" }; } // TODO
async function chemistry() { return { ok: false, error: "not_implemented" }; } // TODO

const handlers = { summary, mindmap, complexity, chemistry };

// ---------- plumbing ----------
function readJson(req) {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk) => {
      data += chunk;
      if (data.length > 500000) { reject(new Error("too large")); req.destroy(); }
    });
    req.on("end", () => { try { resolve(JSON.parse(data || "{}")); } catch (e) { reject(e); } });
    req.on("error", reject);
  });
}

function send(res, status, body) {
  res.writeHead(status, { "Content-Type": "application/json" });
  res.end(JSON.stringify(body));
}

const server = http.createServer(async (req, res) => {
  const task = req.url.startsWith("/api/") ? req.url.slice(5) : null;
  if (req.method !== "POST" || !handlers[task]) return send(res, 404, { ok: false, error: "not_found" });
  let body;
  try { body = await readJson(req); } catch (e) { return send(res, 400, { ok: false, error: "bad_request" }); }
  try { send(res, 200, await handlers[task](body)); }
  catch (e) { console.error(e); send(res, 500, { ok: false, error: "server_error" }); }
});

server.listen(PORT, "127.0.0.1", () => console.log(`Backend on http://localhost:${PORT}`));
