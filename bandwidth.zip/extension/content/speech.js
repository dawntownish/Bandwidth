// Read-aloud using the browser's built-in voices (no AI, no network call from us).
// Speaks one sentence at a time so it can highlight the sentence being read.
(function () {
  const B = (window.Bandwidth = window.Bandwidth || {});
  const synth = window.speechSynthesis;
  let run = 0;

  B.speech = {
    supported: !!synth && typeof SpeechSynthesisUtterance !== "undefined",

    voices() {
      if (!synth) return [];
      const all = synth.getVoices();
      const english = all.filter((v) => /^en/i.test(v.lang));
      return english.length ? english : all;
    },

    // options: getRate(), getVoice(), onSentence(i), onEnd()
    speak(sentences, o) {
      if (!this.supported) return;
      this.stop();
      const id = ++run;
      let i = 0;

      const next = () => {
        if (id !== run) return;
        if (i >= sentences.length) { if (o.onEnd) o.onEnd(); return; }
        const u = new SpeechSynthesisUtterance(sentences[i]);
        u.rate = o.getRate ? o.getRate() : 1;
        const name = o.getVoice ? o.getVoice() : "";
        if (name) {
          const v = synth.getVoices().find((x) => x.name === name);
          if (v) { u.voice = v; u.lang = v.lang; }
        }
        u.onend = () => { if (id === run) { i++; next(); } };
        u.onerror = (e) => {
          if (id !== run) return;
          if (e.error === "canceled" || e.error === "interrupted") return;
          i++; next();
        };
        if (o.onSentence) o.onSentence(i);
        synth.speak(u);
      };
      next();
    },

    pause() { if (synth) synth.pause(); },
    resume() { if (synth) synth.resume(); },
    stop() { run++; if (synth) synth.cancel(); },
  };
})();
