# Bandwidth: setup

## Folders
- extension/  -> what Chrome loads
- backend/    -> the small local server that will talk to Meta's model

## Try the extension (no key needed)
1. Open chrome://extensions and turn on Developer mode.
2. Click "Load unpacked" and choose the `extension` folder (manifest.json must be directly inside).
3. Open any article and press F5. A small "Bandwidth" button appears at the bottom right.
4. Click it. Tabs: Clean (cleaned text, paragraph in the middle of the screen in focus), Cards (the same text in small cards),
   Listen (read aloud in either view) and Settings. Un-Stuck, Mind map and Simplify sit on the same slim header.
   Prev / Next at the bottom move one paragraph (Clean) or one card (Cards).
   Flip the round switch (or press Esc) to go back to the original page.

## Pages on your own computer (file:// pages)
Chrome blocks extensions on local files until you allow it: chrome://extensions -> Bandwidth -> Details ->
turn on "Allow access to file URLs", then refresh the page.

## Where it can't run
chrome:// pages, the Chrome Web Store, and the built-in PDF viewer. That is a Chrome rule.
5. After editing code: press the reload icon on the extension's card, then refresh the page.

Colours and fonts live at the top of extension/panel.css.

## Run the backend (optional until you have the key)
1. Install Node (version 20.6 or newer). Check with: node -v
2. In the `backend` folder, copy `.env.example` to a new file named `.env`.
3. Run: npm start
Without a key, Un-Stuck simply shows "AI isn't set up yet."

## When your keys arrive
Put them in `backend/.env`. Never in the extension, never on GitHub.
- META_API_KEY: Muse Spark through the Meta Model API
- OPEN_API_KEY: Muse Spark Open through Baseten (this is what qualifies for the open-weights bonus)
In `backend/server.js`, TASK_PROVIDER decides which model does which job. If only one key is set, it does everything.
